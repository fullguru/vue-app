"use strict";

(function ($) {
  $.fn.mdbTreeview = function () {
    var $this = $(this);

    if ($this.hasClass('treeview-animated')) {
      var $elements = $this.find('.treeview-animated-element');
      var $closed = $this.find('.closed');
      var $open = $this.find('.open');
      $this.find('.nested').hide();
      $this.find('.open').siblings('.nested').show();
      $closed.off('click');
      $closed.on('click', function () {
        var $this = $(this);
        var $target = $this.siblings('.nested');
        var $pointer = $this.children('.fa-caret-right');
        $this.toggleClass('open');
        $pointer.toggleClass('down');
        !$target.hasClass('active') ? $target.addClass('active').slideDown() : $target.removeClass('active').slideUp();
        return false;
      });
      $elements.off('click');
      $elements.on('click', function () {
        var $this = $(this);
        $this.hasClass('opened') ? $this.removeClass('opened') : ($elements.removeClass('opened'), $this.addClass('opened'));
      });
    }


  };
})(jQuery);
