$(document).ready(function (){
// Swtich viewport

// Swtich viewport

$('input').on('click',function(e) {
    if ($(this).hasClass('list-view-radio')) {
        $('.contacts').removeClass('contacts-grid').addClass('contacts-list');
    }
    else if($(this).hasClass('grid-view-radio')) {
        $('.contacts').removeClass('contacts-list').addClass('contacts-grid');
    }
});


});
