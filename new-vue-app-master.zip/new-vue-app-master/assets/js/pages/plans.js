$(document).ready(function (){
//Plan initial-charges

  $('#plan1').click(function(){
       $('#initial-charge').text('$111.83');
  });


  $('#plan2').click(function(){
       $('#initial-charge').text('$147.23');
  });

  $('#plan3').click(function(){
       $('#initial-charge').text('$201.83');
  });

  $('#plan4').click(function(){
       $('#initial-charge').text('$337.83');
  });

  $('#plan5').click(function(){
       $('#initial-charge').text('$651.83');
  });

  $('#plan6').click(function(){
       $('#initial-charge').text('$951.83');
  });

  $('#plan7').click(function(){
       $('#initial-charge').text('$1351.83');
  });

  $('#plan8').click(function(){
       $('#initial-charge').text('$2227.83');
  });

  $('#plan9').click(function(){
       $('#initial-charge').text('$4351.83');
  });


  $('#proceed-btn').click(function(){
    if ($('.pro-user-name').hasClass("id-not-confirmed")) {
      $(".error-id-not-confirmed").modal("show");
          }
    else if ($('cc-added').length) {
              }
        else {
                  $(".error-no-card").modal("show");
              }
      });


        $('#error-no-card-btn').click(function(){
          $(".error-no-card").modal("hide");
          $(".add-cc").modal("show");
          });



            $("#error-id-not-confirmed-btn").click(function () {
              $(".error-id-not-confirmed").modal("hide");
              $(".verify-identity").modal("show");
              });



});
