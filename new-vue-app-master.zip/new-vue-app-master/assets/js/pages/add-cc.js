$("#verification-button1").click(function () {
  $("#verification-step1").addClass('d-none');
  $("#verification-step2").removeClass('d-none');
});

$("#button_close").click(function () {
  $("#verification-step1").removeClass('d-none');
  $("#verification-step2").addClass('d-none');
});

$("#verification-button2").click(function () {
  $(".add-cc").modal("hide");
});

//Credit card info validation

$('#credit-card-name').keypress(function (e) {
    var regex = new RegExp("^[a-zA-Z \s]+$");
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    if (regex.test(str)) {
      return true;
}
  else
    {
      e.preventDefault();
alert('Only alphabetical characters and spaces are allowed');
return false;}
});

//Credit card info validation

$(document).ready(function (){
    validate();
    $('#credit-card-number, #credit-card-name, #credit-card-expiry-date').change(validate);
});

function validate(){
    if ($('#credit-card-number').val().length   ==   19   &&
        $('#credit-card-name').val().length  >   0   &&
        $('#credit-card-expiry-date').val().length    ==   5) {
        $("#verification-button1").prop("disabled", false);
    }
    else {
        $("#verification-button1").prop("disabled", true);
    }
};

$("#identity-btn6").click(function () {
     $(".verify-identity").modal("hide");
     $(".pro-user-name").removeClass('id-not-confirmed')
});
