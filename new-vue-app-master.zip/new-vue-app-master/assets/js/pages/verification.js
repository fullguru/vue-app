$(document).ready(function() {

  $("#verification-form").submit(function (e) {
    e.preventDefault();
       $(".verify-identity").modal("hide");
       $(".pro-user-name").removeClass('id-not-confirmed')
  });

  $("#select-passport").click(function () {
    $("#upload-passport").removeClass('d-none');
    $("#upload-national-id").addClass('d-none');
    $("#upload-drivers-licence").addClass('d-none');

  });

  $("#select-id-card").click(function () {
    $("#upload-national-id").removeClass('d-none');
    $("#upload-passport").addClass('d-none');
    $("#upload-drivers-licence").addClass('d-none');
  });

  $("#select-drivers-licence").click(function () {
    $("#upload-drivers-licence").removeClass('d-none');
    $("#upload-national-id").addClass('d-none');
    $("#upload-passport").addClass('d-none');
  });

});
