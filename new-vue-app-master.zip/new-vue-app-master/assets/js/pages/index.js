$(document).ready(function (){

  var target;
//Dialpad

  $('.dial_button').click(function(){
      var id = $(this).attr('data-id');
      var val = $('#dial_telephone').val();
      val += id;
      $('#dial_telephone').val(val);
  });

  $(document).on('click', '.minimize-button', function () {
    if($('.header-button').hasClass('header-button-expanded')) {
      $('.card-body').addClass('d-none');
      $('.header-button').removeClass('header-button-expanded');
      $('.minimize-button').removeClass('fa-minus-square');
      $('.minimize-button').addClass('fa-caret-square-down');
      console.log('1');
      }
      else {
      $('.card-body').removeClass('d-none');
      $('.header-button').addClass('header-button-expanded');
      $('.minimize-button').addClass('fa-minus-square');
      $('.minimize-button').removeClass('fa-caret-square-down');
      console.log('2');

      }

    });

    $(document).on('click', '.phrase-dismiss', function () {
      $(this).parent().parent().remove();
      var phrases = $('.training-phrases-list tr').length;
      console.log(phrases);
      if(phrases==0) {
      $('.training-phrases').parent().parent().remove();
      }
      });

      $(document).on('click', '.phrase-assign', function () {
       target=$(this).parent().parent();
     });

      $(document).on('click', '#assign-phrase-btn', function () {
        $(".assign-phrase").modal("hide");
        target.remove();
        var phrases = $('.training-phrases-list tr').length;
        if(phrases==0) {
        $('.training-phrases').parent().parent().remove();
        }
        });

});
