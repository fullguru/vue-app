$(document).ready(function() {

  var options = [];
  var requiredTarget;
  var unassginedUsers;

  $('.treeview-animated').mdbTreeview();


  //DELETE TYPE
  $(document).on('click', '.delete-type-btn', function () {
      var grandparent = $(this).parent().parent();
      var type_name;
      type_name = grandparent.children('.closed').children('span').html();
      $('#delete-type-btn').click(function(){
      grandparent.remove();
      $(".delete-type").modal("hide");
      toastr.success('Call type "' + type_name + '" deleted succesfully.');
        });
    });

  var $list;

  //CREATE RULE
  $(document).on('click', '.add-rule-btn', function () {
      $list = $(this).parent().next();
  });
  $(document).on('click', '#create-rule-btn', function (e) {
    e.preventDefault();
        var rule_name = $('#call-rule-name:text').val();
        var type_name;
        $list.append('<li class="treeview-animated-element"><span class="call-rule">' + rule_name + '</span></li>');
        $list.siblings('.closed').addClass('open');
        type_name=$list.siblings('.closed').children('span').html();
        $list.siblings('.closed').children('.fa-caret-right').addClass('down');
        $list.addClass('active');
        $('.treeview-animated').mdbTreeview();
        $(".add-new-rule").modal("hide");
        $('#call-rule-name').val('');
        toastr.success('Call rule "' + rule_name + '" added to "' + type_name +'".');
        $('#create-rule-btn').prop('disabled', 'disabled');
    });

    $("#create-type-form").parsley();
      $('input').on('keyup', function() {
        $("#create-type-form").parsley().validate();
          if ($("#create-type-form").parsley().isValid()) {
              $('#create-type-btn').prop('disabled', false);
          } else {
              $('#create-type-btn').prop('disabled', 'disabled');
          }
      });

      $("#create-rule-form").parsley();
        $('input').on('keyup', function() {
          $("#create-rule-form").parsley().validate();
            if ($("#create-rule-form").parsley().isValid()) {
                $('#create-rule-btn').prop('disabled', false);
            } else {
                $('#create-rule-btn').prop('disabled', 'disabled');
            }
        });

        $("#create-field-form").parsley();
          $(':input').on('edit change keyup', function() {
            $("#create-field-form").parsley().validate();
              if ($("#create-field-form").parsley().isValid()) {
                  $('#create-field-btn').prop('disabled', false);
              } else {
                  $('#create-field-btn').prop('disabled', 'disabled');
              }
          });

            $(':input').on('edit change keyup', function() {
              $("#edit-field-form").parsley().validate();
                if ($("#edit-field-form").parsley().isValid()) {
                    $('#save-field-btn').prop('disabled', false);
                } else {
                    $('#save-field-btn').prop('disabled', 'disabled');
                }
            });

//CREATE NEW BUTTON
    $(document).on('click', '#create-type-btn', function (e) {
      e.preventDefault();
    var $typelist;
    $typelist = $('.treeview-animated-list');
    var type_name = $('#call-type-name:text').val();
    $typelist.append('<li class="treeview-animated-items"><a class="closed"><i class="fas fa-caret-right mr-2"></i><span>' + type_name + '</span></a><span class="call-rule-buttons"><i class="fas add-rule-btn fa-plus" data-toggle="modal" data-target=".add-new-rule" data-backdrop="static" data-keyboard="false"></i><i class="fas delete-type-btn fa-trash" data-toggle="modal" data-target=".delete-type" data-backdrop="static" data-keyboard="false"></i></span><ul class="nested"><li class="treeview-animated-element"><span class="call-rule">New call rule</span></li></ul></li>');
    $typelist = $('.treeview-animated-list');
    var last=$('.treeview-animated-items').last();
    var closed=last.children('.closed')
    closed.addClass('open');
    last.children('.nested').addClass('active');
    closed.children('.fa-caret-right').addClass('down');
    $('.treeview-animated').mdbTreeview();
    $(".add-new-type").modal("hide");
    toastr.success('Call type "' + type_name + '" created.');
    $('#call-type-name').val('');
    $('#create-type-btn').prop('disabled', 'disabled');
  });

  var name;
  var img;
  var assign;


  //UNASSIGN USER

  $(document).on('click', '.delete-user-btn', function (){
    name = $(this).next().next().children().html();
    img = $(this).next().attr('src');
    assign=$('#assign-users-modal');
    assign.append('<div class="assign-modal"><img src="'+ img + '" class="contact-image img-center text-center d-block rounded-circle avatar-md" alt="profile-image"><div class="contact-name text-center"><h5>' + name + ' </h5></div><button class="btn btn-success btn-xs btn-block waves-effect waves-light add-user-btn">Assign</button></div>');
    var parent = $(this).parent();
    parent.remove();
    countUsers();
    console.log(unassginedUsers);
    if(unassginedUsers==0) {
      $('#assign-users-modal .h4').removeClass('d-none');
    }
    else {
      $('#assign-users-modal .h4').addClass('d-none');
    }
  });

  //ASSIGN USER

  $(document).on('click', '.add-user-btn', function () {
   name = $(this).prev().children().html();
   img = $(this).prev().prev().attr('src');
   assign= $('#assign-users');
   unassginedUsers = $('#assign-users-modal .assign-modal').length;
   $('<div class="assign-user"><div class="float-right delete-user-btn"><i class="fas fa-trash tltp" data-tippy-content="Unassign user"></i></div><img src="'+ img + '" class="contact-image img-center text-center d-block rounded-circle avatar-md" alt="profile-image"><div class="contact-name text-center"><h5>' + name + ' </h5></div><button class="btn btn-xs btn-block transfer">Transfer online</button></div>').insertBefore('.assign-user:last');
   tippy('.tltp');
   countUsers();
   $(this).parent().remove();
   console.log(unassginedUsers);
   if(unassginedUsers==1) {
     $('#assign-users-modal .h4').removeClass('d-none');
   }
   else {
     $('#assign-users-modal .h4').addClass('d-none');
   }
});

//Transfer enable/disable
  $(document).on('click', '.transfer', function () {
   if ($(this).hasClass("transfer-disabled"))
   {   $( this ).removeClass("transfer-disabled" );
   $( this ).html( "Transfer online" );
 }
  else {
    $( this ).addClass( "transfer-disabled" );
    $( this ).html( "Transfer disabled" );
  }

 });

 //Call escalation and distribution
 function countUsers() {
   var m = $("#assign-users > .assign-user").length;
   var assignuser = $( ".assign-user" );
   if (m>2) {
     $('.distribution').removeClass('icon-disabled');
     $('.escalation').removeClass('icon-disabled');

   }
   else {
     $('.distribution').addClass('icon-disabled');
     $('.escalation').addClass('icon-disabled');
   }
 }

countUsers();

//
 $(document).on('click', '.assign-users-icon', function () {
  if ($(this).hasClass("assign-users-icon-active"))
  {   $( this ).removeClass("assign-users-icon-active" );
}
 else {
   $( this ).addClass( "assign-users-icon-active" );
 }

});

//WARM CALL

$(document).on('click','.warm-call', function () {
 if ($(this).hasClass("warm-call-active"))
 {   $( this ).removeClass("warm-call-active" );
}
else {
  $( this ).addClass( "warm-call-active" );
}

});

//ADD PHRASES

$(document).on('click','#add-phrases-btn', function () {
  var phrases = $('#more-phrases');
  phrases.append('<div class="phrase"><input type="text" class="form-control" placeholder="Enter another phrase"><span class="phrase-buttons"><i class="fas delete-phrase-btn fa-trash"></i></span></div>');
  phrases.css("border-width", "1px");
});

//DELETE PHRASES

$(document).on('click','.delete-phrase-btn', function () {
  var phrases = $('#more-phrases');
  var target= $(this).parent().parent();
  target.remove();
  var m = $(".phrase").length;
  if (m==0) {
    phrases.css("border-width", "0px");
  }
});

//ASSIGNED USERS SORTABLE

$( function() {
  $( "#assign-users" ).sortable({
  items: ">.assign-user:not(.add-user)",
  cursor: "move",
  delay: 500,
  distance: 5,
  opacity: 0.5,
  tolerance: "pointer"
});
  $( "#assign-users" ).disableSelection();
});

//CREATE FIELD VALIDATION

$(':input').on('change', function() {
  var type = $('#field-type').val();
  if (type=='date') {
    $('#field-filled').addClass('d-none');
    $('#field-options').parent().addClass('d-none');
  }
  else if (type=='select') {
    $('#field-filled').addClass('d-none');
    $('#field-options').parent().removeClass('d-none');
  }
  else {
    $('#field-filled').removeClass('d-none');
    $('#field-options').parent().addClass('d-none')
  }
});

var optionString="";

//CREATING NEW FIELD
$(document).on('click', '#create-field-btn', function (e) {
  e.preventDefault();
  var n=$(".field").length;
  var row=$('.field').last().parent().parent();
  var lastField=$('.field').last().parent();
  var col=$('.field').last().parent();
  var label = $('#field-label').val();
  var type = $('#field-type').val();
  var type_HTML;
  var filled = $('#field-filled').val();
  required = $('#field-required').val();
  var len;
  var u;
  var t=0;
  $("#select-wrap .tag").each(function() {
    u = $(this);
    t++;
     options.push($(this).text());
     console.log(this);
     u.remove();
     console.log(t);
   });
   console.log(options);
   len=options.length;
   console.log(len);
  for (var i = 0; i < len; i++) {
    var m;
    m='<option>'+options[i]+'</option>';

    optionString=optionString+m;
  }
  console.log(optionString);

  if(type=='text'){
    type_HTML='<input type="text" class="form-control form-control-sm" value="'+filled+'">';
    type_class="text";
    }
    else if (type=='textarea') {
      type_HTML='<textarea type="textarea" style="height:75px;" class="form-control form-control-sm">'+filled+'</textarea>';
      type_class="textarea";
    }
    else if (type=='select') {
      type_HTML='<select class="form-control form-control-sm select">'+optionString+'</select>';
      type_class="select";
    }

    else if (type=='date') {
      type_HTML='<input type="date" class="form-control form-control-sm">';
      type_class="date";
    }

    if(required=='yes') {
      required_HTML='<span class="label-additional required">(Required)</span>';
    }
    else {
      required_HTML='<span class="label-additional"></span>';
    }

    lastField.after('<div class="col-12 col-sm-6 col-lg-12 col-xl-6"><div class="field custom-field '+type_class+'"><span class="label">'+label+'</span>'+required_HTML+type_HTML+'</div></div>');
      optionString="";

$(".add-new-field").modal("hide");
$('#field-label').val('');
$('#field-type').val('select');
$('#field-filled').val('');
$('#field-required').val('required');
$('#field-options').tagsinput('removeAll');
$('#create-field-btn').prop('disabled', 'disabled');
$("#create-field-form").parsley().validate();

$('#create-field-form').trigger("reset");

});

//EDIT CUSTOM FIELD
var field;
var fieldLabel;
var label;
var select;
var required;
var filled;
var element;
$(document).on('click', '.custom-field', function () {
  field=$(this);
  element= $(this).find('input');
  fieldLabel= $(this).find('.label');
  label = $(this).find('.label').html();
  select = $(this).find('select');
  $(".edit-field").modal("show");
  $('#edit-field-label').val(label);

//check if the field is required
  if ($(this).children().hasClass('required')) {
    $('#edit-field-required').val("yes");
  }
  else {
    $('#edit-field-required').val("no");
  }

  //check if the field is required

  if ($(this).hasClass('text')) {
     filled = $(this).find('input').val();
     $('#edit-field-filled').val(filled);
  }

  else if ($(this).hasClass('textarea')) {
     filled = $(this).find('textarea').html();
     var element= $(this).find('textarea');
     $('#edit-field-filled').val(filled);
  }

  else if ($(this).hasClass('date')) {
     $('#edit-field-filled').addClass('d-none');
  }

  else if ($(this).hasClass('select')) {
     $('#edit-options').parent().removeClass('d-none');
     $('#edit-field-filled').addClass('d-none');
     var optionsList=[];
     optionsLen=$('.select option').length;
      $(".select > option").each(function() {
      optionsList.push($(this).text());
});
      for (var i = 0; i <= optionsLen; i++){
      $('#edit-options').tagsinput('add', optionsList[i]);
}
optionsList=[];
  }

  optionsList=[];
});
  $(document).on('click', '#delete-field-btn', function () {
    field.parent().remove();
    $(".edit-field").modal("hide");

});

$(document).on('click', '#save-field-btn', function (e) {
  e.preventDefault();
  requiredTarget=$(field).children('.label-additional');
  label=$('#edit-field-label').val();
  fieldLabel.html(label);
  type = $('#edit-field-required').val();

  //Change filled

  if(field.hasClass('text')) {
    filled = $('#edit-field-filled').val();
    element.val(filled);
  }

  else if(field.hasClass('textarea')) {
    filled = $('#edit-field-filled').val();
    element.html(filled);
  }

  else if(field.hasClass('select')) {
    options = [];
    optionsString="";
    var selectHTML="";
      $("#edit-field-form .tag").each(function() {
        options.push($(this).text());
      });
     var m="";
     len=options.length;
     for (var i = 0; i <len; i++) {
       m='<option>'+options[i]+'</option>';
       optionsString=optionsString+m;
     }
    select.html(optionsString);
    options = [];
    optionsString="";
  }

//Change required
  if (type=='yes') {
    requiredTarget.html('(Required)');
    requiredTarget.addClass('required');
  }
  else {
    requiredTarget.html('');
    requiredTarget.removeClass('required');
  }
  $(".edit-field").modal("hide");
console.log(field);
});


});
